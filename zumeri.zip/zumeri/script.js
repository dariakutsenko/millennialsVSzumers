document.addEventListener('DOMContentLoaded', () => {

  const mBurger = document.getElementById('mBurger');
  const zBurger = document.getElementById('zBurger');
  const mNav = document.getElementById('mNav');
  const zNav = document.getElementById('zNav');

  if (mBurger && mNav) {
    mBurger.addEventListener('click', () => mNav.classList.toggle('is-open'));
  }
  if (zBurger && zNav) {
    zBurger.addEventListener('click', () => zNav.classList.toggle('is-open'));
  }
  document.querySelectorAll('.m-nav a, .z-nav a').forEach(link => {
    link.addEventListener('click', () => {
      if (mNav) mNav.classList.remove('is-open');
      if (zNav) zNav.classList.remove('is-open');
    });
  });
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      const href = link.getAttribute('href');
      if (href.length < 2) return; 

      const target = document.querySelector(href);
      if (!target) return;

      e.preventDefault();
      const headerOffset = 80; 
      const y = target.getBoundingClientRect().top + window.pageYOffset - headerOffset;
      window.scrollTo({ top: y, behavior: 'smooth' });
    });
  });
  document.querySelectorAll('.m-acc-head, .z-acc-head').forEach(head => {
    head.addEventListener('click', () => {
      const item = head.parentElement;
      const isActive = item.classList.contains('active');
      const accordion = item.parentElement;
      accordion
        .querySelectorAll('.m-acc-item, .z-acc-item')
        .forEach(i => i.classList.remove('active'));
      if (!isActive) item.classList.add('active');
    });
  });
  const animatedItems = document.querySelectorAll(
    '.m-card--adv, .m-course, .m-teacher, .m-review, .m-tariff, ' +
    '.z-bento__item, .z-course, .z-teacher, .z-review, .z-tariff, .z-step'
  );

  if ('IntersectionObserver' in window && animatedItems.length) {const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });

    animatedItems.forEach(el => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(20px)';
      el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      io.observe(el);
    });
  }
});